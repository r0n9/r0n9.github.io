export default {
  /**
   * validate the formdata
   * or get the formdata
   * @param {*} formdata
   */
  checkOrGetFormData(formdata) {
    const fileds = ['sender_email', 'sender_name', 'recipient_name', 'recipient_email', 'subject', 'message'];
    const result = [];
    let error = '';
    fileds.forEach((item) => {
      const value = formdata.get(item);
      console.debug(item, value);
      if (!value || value === '' || value === undefined || value === null) {
        error = `Request params :${item} error`;
      }
      result[item] = value;
    });
    if (error != '') {
      return null;
    }
    return result;
  },

  async sendEmail(data, env) {
    try {
      const response = await fetch('https://api.mailchannels.net/tx/v1/send', {
        method: 'POST',
        headers: {
          'content-type': 'application/json'
        },
        body: JSON.stringify({
          personalizations: [
            {
              to: [{
                email: data.recipient_email, 
                name: data.recipient_name
              }],
              dkim_domain: "memoflare.com", // add your domain
              dkim_selector: "mailchannels",
              dkim_private_key: env.DKIM_PRIVATE_KEY,
            }
          ],
          from: {
            email: data.sender_email,
            name: data.sender_name
          },
          subject: data.subject,
          content: [
            {
              type: 'text/html',
              value: data.message
            }
          ]
        })
      });
      return response;
    } catch (error) {
      console.debug('Error sending email:', error);
      return null;  // 或返回一个错误响应
    }
  },
  async fetch(request, env) {
    if (request.method !== 'POST') {
      console.debug('Request method must be POST');
      return new Response('Request method must be POST', {
        status: 404
      });
    }

    const formdata = await request.formData();
    const data = this.checkOrGetFormData(formdata);
    if (!data) {
      return new Response('Request params error', {
        status: 400
      });
    }

    // console.debug("DKIM_PRIVATE_KEY=", env.DKIM_PRIVATE_KEY);

    const emailResponse = await this.sendEmail(data, env);

    if (!emailResponse) {
      return new Response('Failed to send email', { status: 500 });
    }

    return new Response(emailResponse.status === 202 ? 'Email sent successfully' : 'Failed to send email', {
      status: emailResponse.status
    });
  }
};
