curl -d"sender_email=no-reply@system.willin.wang&sender_name='No Reply'&recipient_email=hi@mt.ci&subject='Hello Guy!'&message='My first email sent!'" "https://send-email-service.willin.workers.dev"
